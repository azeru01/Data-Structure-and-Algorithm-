
import java.util.Arrays;

public class InsertionSortChar {

	//Sort an array of chars using the insertion sort algorithm
	public static void insertionSort(char[ ] data) {
		int n = data.length;
		//Loop from the second element to the end
		for (int k = 1; k < n; k++) {    // begin with second element
			//At the end of the kth iteration, we've sorted k elements
		    char cur = data[k];          // save data[k] in cur
		    int j = k;                   
		    while (j > 0 && data[j-1] > cur) {
		    	// find correct index j for cur in the sorted part of the
				//array
		        data[j] = data[j-1];            
		        j--;                            
		    } // while
		    data[j] = cur;     // this is the proper place for cur
		 } // for
	}

	//A main method to test the insertion sort code
	public static void main(String[] args) {

		//Create char array
		char[] charArray = {'B', 'C', 'D', 'A', 'E', 'H', 'G', 'F'};

		//Print array before and after sorting
		System.out.println("Before sorting: " + Arrays.toString(charArray));
		System.out.println();
		
		insertionSort(charArray);
		System.out.println("After sorting: " + Arrays.toString(charArray));
	}

}
